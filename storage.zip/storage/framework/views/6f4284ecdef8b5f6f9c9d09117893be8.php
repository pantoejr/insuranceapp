
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow-sm border-0">
                <div class="card-header">
                    <div class="card-title"><?php echo e($title); ?></div>
                    <div class="card-tools">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-payment')): ?>
                            <a href="<?php echo e(route('payments.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-circle"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table dataTable nowrap">
                            <thead>
                                <tr>
                                    <td>#</td>
                                    <td>Invoice No.</td>
                                    <td>Amount Paid</td>
                                    <td>Payment Date</td>
                                    <td>Payment Method</td>
                                    <td>Status</td>
                                    <td>Actions</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($payment->invoice_id); ?></td>
                                        <td><?php echo e($payment->amount_paid); ?></td>
                                        <td><?php echo e($payment->payment_date); ?></td>
                                        <td><?php echo e(ucfirst($payment->payment_method)); ?></td>
                                        <td>
                                            <span
                                                class="badge bg-<?php echo e($payment->status == 'rejected' ? 'danger' : ($payment->status == 'approved' ? 'success' : ($payment->status == 'pending' ? 'warning' : 'primary'))); ?>">
                                                <?php echo e(ucfirst($payment->status)); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('payments.edit', ['id' => $payment->id])); ?>"
                                                class="btn btn-warning btn-sm"><i class="bi bi-pencil-fill"></i></a>
                                            <a href="<?php echo e(route('payments.details', ['id' => $payment->id])); ?>"
                                                class="btn btn-primary btn-sm"><i class="bi bi-journal-text"></i></a>
                                            <a href="<?php echo e(route('payments.destroy', ['id' => $payment->id])); ?>"
                                                class="btn btn-danger btn-sm" onclick="confirmDelete(event)"><i
                                                    class="bi bi-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/payments/index.blade.php ENDPATH**/ ?>