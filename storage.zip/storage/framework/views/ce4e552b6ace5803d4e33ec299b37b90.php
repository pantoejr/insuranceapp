

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card border-0 mb-4 shadow-sm">
                <div class="card-header">
                    <div class="card-title">Policy Details</div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="name" class="form-label">Name</label>
                                <input type="text" class="form-control" id="name" name="name"
                                    value="<?php echo e($policy->name); ?>" disabled>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="number" class="form-label">Number</label>
                                <input type="text" class="form-control" id="number" name="number"
                                    value="<?php echo e($policy->number); ?>" disabled>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="description" class="form-label">Description</label>
                                <textarea class="form-control" id="description" name="description" disabled><?php echo e($policy->description); ?></textarea>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="coverage_details" class="form-label">Coverage Details</label>
                                <textarea class="form-control" id="coverage_details" name="coverage_details" disabled><?php echo e($policy->coverage_details); ?></textarea>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="premium_amount" class="form-label">Premium Amount</label>
                                <input type="number" class="form-control" id="premium_amount" name="premium_amount"
                                    value="<?php echo e($policy->premium_amount); ?>" disabled>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="premium_frequency" class="form-label">Premium Frequency</label>
                                <input type="text" class="form-control" id="premium_frequency" name="premium_frequency"
                                    value="<?php echo e(ucfirst($policy->premium_frequency)); ?>" disabled>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="currency" class="form-label">Currency</label>
                                <input type="text" class="form-control" id="currency" name="currency"
                                    value="<?php echo e(strtoupper($policy->currency)); ?>" disabled>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="terms_conditions" class="form-label">Terms & Conditions</label>
                                <textarea class="form-control" id="terms_conditions" name="terms_conditions" disabled><?php echo e($policy->terms_conditions); ?></textarea>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="eligibility" class="form-label">Eligibility</label>
                                <input type="text" class="form-control" id="eligibility" name="eligibility" disabled
                                    value="<?php echo e(strtoupper($policy->eligibility)); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="status" class="form-label">Status</label>
                                <input type="text" class="form-control" id="status" name="status"
                                    value="<?php echo e(ucfirst($policy->status)); ?>" disabled>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <a href="<?php echo e(route('policies.index')); ?>" class="btn btn-light">Back to List</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('policies.partials.insurer_policies', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/policies/details.blade.php ENDPATH**/ ?>