

<?php $__env->startSection('title', '403 Forbidden'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container text-center">
        <h1 class="display-1">403</h1>
        <p class="lead">Forbidden</p>
        <p>You do not have permission to access this page.</p>
        <a href="<?php echo e(url('/')); ?>" class="btn btn-primary">Go Home</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/errors/403.blade.php ENDPATH**/ ?>