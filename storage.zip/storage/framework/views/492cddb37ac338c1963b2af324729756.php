
<?php $__env->startSection('content'); ?>
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card shadow-sm mb-4" style="border:none;">
                <div class="card-header" style="border:none;">
                    <div class="card-title"><?php echo e($title); ?></div>
                </div>
                <div class="card-body">
                    <div class="form-group mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control" id="name" value="<?php echo e($role->name); ?>" readonly>
                    </div>
                    <div class="form-group">
                        <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-light">Back to List</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Superadmin')): ?>
        <div class="row">
            <div class="col-lg-6">
                <div class="card card-success card-outline mb-4">
                    <div class="card-header">
                        <div class="card-title">Add Permissions for <?php echo e($role->name); ?></div>
                    </div>
                    <div class="card-body" style="overflow: auto; height: 300px;">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('role.add-permission', ['roleId' => $role->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1957371346-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card card-danger card-outline mb-4">
                    <div class="card-header">
                        <div class="card-title">Remove Permissions for <?php echo e($role->name); ?></div>
                    </div>
                    <div class="card-body" style="overflow: auto; height: 300px;">
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('role.remove-permission', ['roleId' => $role->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1957371346-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/roles/details.blade.php ENDPATH**/ ?>