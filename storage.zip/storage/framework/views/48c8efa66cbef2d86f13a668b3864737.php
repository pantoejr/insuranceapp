<div class="row mb-3">
    <div class="col-md-12">
        <div class="card shadow-sm border-0">
            <div class="card-header">
                <div class="card-title" id="employee-header" style="cursor: pointer;"><?php echo e($model->full_name); ?> Employees
                </div>
                <div class="card-tools">
                    <a href="<?php echo e(route('employees.create', ['client' => $model])); ?>" class="btn btn-primary"><i
                            class="bi bi-plus-circle"></i></a>
                </div>
            </div>
            <div class="card-body table-responsive" id="employee-body">
                <div class="table-responsive">
                    <table class="table table-striped dataTable nowrap">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Gender</th>
                                <th>Position</th>
                                <th>Email</th>
                                <th>Action(s)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $model->employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($employee->employee_name); ?></td>
                                    <td><?php echo e(ucfirst($employee->gender)); ?></td>
                                    <td><?php echo e($employee->position); ?></td>
                                    <td><?php echo e($employee->email); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('employees.edit', ['employee' => $employee->id, 'client' => $model])); ?>"
                                            class="btn btn-warning btn-sm"> <i class="bi bi-pencil-fill"></i></a>
                                        <a href="<?php echo e(route('employees.details', ['employee' => $employee->id, 'client' => $model])); ?>"
                                            class="btn btn-primary btn-sm"><i class="bi bi-eye-fill"></i></a>
                                        <form
                                            action="<?php echo e(route('employees.destroy', ['employee' => $employee->id, 'client' => $model])); ?>"
                                            method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger btn-sm delete-btn"><i
                                                    class="bi bi-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/clients/partials/client_employees.blade.php ENDPATH**/ ?>