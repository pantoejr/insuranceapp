

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow-sm mb-4" style="border:none;">
                <div class="card-header" style="border:none;">
                    <div class="card-title"><?php echo e($title); ?></div>
                </div>
                <div class="card-body">
                    <div class="form-group mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" name="name" id="name" class="form-control"
                            value="<?php echo e($systemVariable->name); ?>" readonly>
                    </div>
                    <div class="form-group mb-3">
                        <label for="type" class="form-label">Type</label>
                        <input type="text" name="type" id="type" class="form-control"
                            value="<?php echo e($systemVariable->type); ?>" readonly>
                    </div>
                    <div class="form-group mb-3">
                        <label for="value" class="form-label">Value</label>
                        <?php if($systemVariable->type == 'logo'): ?>
                            <div>
                                <img src="<?php echo e(asset('storage/' . $systemVariable->value)); ?>" alt="Logo Preview"
                                    style="max-width: 200px; margin-top: 10px;">
                            </div>
                        <?php else: ?>
                            <input type="text" name="value" id="value" class="form-control"
                                value="<?php echo e($systemVariable->value); ?>" readonly>
                        <?php endif; ?>
                    </div>
                    <a href="<?php echo e(route('system-variables.index')); ?>" class="btn btn-white">Back to List</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/system_variables/details.blade.php ENDPATH**/ ?>