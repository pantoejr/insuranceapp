<div class="row mb-3">
    <div class="col-md-12">
        <div class="card border-0 shadow-sm">
            <div class="card-header">
                <div class="card-title" id="policy-header" style="cursor: pointer;"><?php echo e($model->full_name); ?> Policies</div>
                <div class="card-tools">
                    <a href="<?php echo e(route('client-policies.create', ['client' => $model])); ?>" class="btn btn-primary"><i
                            class="bi bi-plus-circle"></i></a>
                </div>
            </div>
            <div class="card-body" id="policy-body">
                <div class="table-responsive">
                    <table class="table dataTable nowrap">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Policy</th>
                                <th>Insurer</th>
                                <th>Assigned By</th>
                                <th>Status</th>
                                <th>Action(s)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $model->policyAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clientPolicy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($clientPolicy->policy->name); ?></td>
                                    <td><?php echo e($clientPolicy->insurer->company_name); ?></td>
                                    <td><?php echo e($clientPolicy->created_by); ?></td>
                                    <td>
                                        <?php if($clientPolicy->status === 'draft'): ?>
                                            <span
                                                class="badge bg-primary"><?php echo e(strtoupper($clientPolicy->status)); ?></span>
                                        <?php elseif($clientPolicy->status === 'submitted'): ?>
                                            <span class="badge bg-info"><?php echo e(strtoupper($clientPolicy->status)); ?></span>
                                        <?php elseif($clientPolicy->status === 'pending'): ?>
                                            <span
                                                class="badge bg-warning"><?php echo e(strtoupper($clientPolicy->status)); ?></span>
                                        <?php elseif($clientPolicy->status === 'approved'): ?>
                                            <span
                                                class="badge bg-success"><?php echo e(strtoupper($clientPolicy->status)); ?></span>
                                        <?php elseif($clientPolicy->status === 'completed'): ?>
                                            <span
                                                class="badge bg-success"><?php echo e(strtoupper($clientPolicy->status)); ?></span>
                                        <?php endif; ?>
                                    </td>

                                    <td>
                                        <a href="#" class="btn btn-warning btn-sm"><i
                                                class="bi bi-pencil-fill"></i></a>
                                        <a href="#" class="btn btn-primary btn-sm"><i
                                                class="bi bi-journal-text"></i></a>
                                        <form action="#" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger btn-sm delete-btn">
                                                <i class="bi bi-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/clients/partials/policy_list.blade.php ENDPATH**/ ?>