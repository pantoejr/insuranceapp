

<div class="row mb-3">
    <div class="col-md-3 mb-3">
        <div class="list-group shadow-sm bg-white p-2" style="min-height: 450px;">
            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="#" class="list-group-item bg-white  list-group-item-action border-0"
                    id="<?php echo e($section['id']); ?>-link">
                    <i class="bi bi-<?php echo e($section['icons']); ?>"></i>&nbsp;
                    &nbsp;<?php echo e($section['title']); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="col-md-9">
        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div id="<?php echo e($section['id']); ?>" class="section-content <?php echo e($loop->first ? '' : 'd-none'); ?>">
                <?php echo $__env->make($section['view'], ['model' => $model], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<script>
    $(document).ready(function() {
        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            $('#<?php echo e($section['id']); ?>-link').on('click', function() {
                showSection('<?php echo e($section['id']); ?>');
            });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        function showSection(sectionId) {
            $('.section-content').addClass('d-none');
            $('#' + sectionId).removeClass('d-none');
        }
    });
</script>
<?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/components/section-navigation.blade.php ENDPATH**/ ?>