<form wire:submit.prevent="submit">
    <?php echo csrf_field(); ?>
    <!--[if BLOCK]><![endif]--><?php if($rolePermissions->isEmpty()): ?>
        <p>No permissions available to revoke for this role.</p>
    <?php else: ?>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $rolePermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissionId => $permissionName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group">
                <input wire:model="removableSelectedPermissions" type="checkbox" value="<?php echo e($permissionId); ?>"
                    id="permission-<?php echo e($permissionId); ?>" />
                <label for="permission-<?php echo e($permissionId); ?>"><?php echo e($permissionName); ?></label>
            </div>
            <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        <button type="submit" class="btn btn-danger w-100">Revoke Permissions</button>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</form>
<?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/livewire/role/remove-permission.blade.php ENDPATH**/ ?>