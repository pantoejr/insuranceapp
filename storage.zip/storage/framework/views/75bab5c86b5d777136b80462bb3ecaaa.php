
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="col-md-12">
                <div class="card shadow-sm mb-4" style="border:none;">
                    <div class="card-header" style="border:none;">
                        <div class="card-title"><?php echo e($title); ?></div>
                        <div class="card-tools">
                            <a href="<?php echo e(route('system-variables.create')); ?>" class="btn btn-primary "><i
                                    class="bi bi-plus-circle"></i>
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table dataTable nowrap">
                                <thead>
                                    <tr>
                                        <td>#</td>
                                        <td>Name</td>
                                        <td>Type</td>
                                        <td>Action(s)</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $systemVariables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($variable->name); ?></td>
                                            <td><?php echo e($variable->type); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('system-variables.edit', $variable->id)); ?>"
                                                    class="btn btn-warning btn-sm"><i class="bi bi-pencil-fill"></i>
                                                    Edit</a>
                                                <a href="<?php echo e(route('system-variables.details', $variable->id)); ?>"
                                                    class="btn btn-primary btn-sm"><i class="bi bi-book-fill"></i>
                                                    Details</a>
                                                <a href="<?php echo e(route('system-variables.destroy', ['id' => $variable->id])); ?>"
                                                    class="btn btn-danger btn-sm" onclick="confirmDelete(event)"><i
                                                        class="bi bi-trash"></i>Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/system_variables/index.blade.php ENDPATH**/ ?>