
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow-sm border-0">
                <div class="card-header">
                    <div class="card-title"><?php echo e($title); ?></div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped dataTable nowrap">
                            <thead>
                                <tr>
                                    <td>#</td>
                                    <td>Invoice No.</td>
                                    <td>Status</td>
                                    <td>Due</td>
                                    <td>Actions</td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('invoices.details', ['id' => $invoice->invoice_id])); ?>"
                                                class="text-decoration-none">
                                                <?php echo e($invoice->invoice_id); ?>

                                            </a>
                                        </td>
                                        <td>
                                            <span
                                                class="badge bg-<?php echo e($invoice->status === 'Paid' ? 'success' : ($invoice->status === 'Partially-Paid' || $invoice->status === 'Pending' ? 'warning' : ($invoice->status === 'Overdue' ? 'danger' : ($invoice->status === 'Cancelled' ? 'secondary' : 'primary')))); ?>">
                                                <?php echo e(ucfirst($invoice->status)); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e(ucfirst($invoice->due_date)); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('invoices.edit', ['id' => $invoice->invoice_id])); ?>"
                                                class="btn btn-warning btn-sm"><i class="bi bi-pencil-fill"></i></a>
                                            <a href="<?php echo e(route('invoices.details', ['id' => $invoice->invoice_id])); ?>"
                                                class="btn btn-primary btn-sm"><i class="bi bi-journal-text"></i></a>
                                            <a href="<?php echo e(route('invoices.destroy', ['id' => $invoice->invoice_id])); ?>"
                                                class="btn btn-danger btn-sm" onclick="confirmDelete(event)"><i
                                                    class="bi bi-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/invoices/index.blade.php ENDPATH**/ ?>