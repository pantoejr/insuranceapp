

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header">
                    <div class="card-title">Policies</div>
                    <div class="card-tools">
                        <a href="<?php echo e(route('policies.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-circle"></i></a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table dataTable nowrap">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Number</th>
                                    <th>Premium Amount</th>
                                    <th>Currency</th>
                                    <th>Premium Frequency</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $policies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($policy->name); ?></td>
                                        <td><?php echo e($policy->number); ?></td>
                                        <td><?php echo e($policy->premium_amount); ?></td>
                                        <td><?php echo e(strtoupper($policy->currency)); ?></td>
                                        <td><?php echo e(ucfirst($policy->premium_frequency)); ?></td>
                                        <td>
                                            <span
                                                class="p-1 btn btn-sm <?php if($policy->status === 'active'): ?> btn-success
                                            <?php else: ?> btn-danger <?php endif; ?>"><?php echo e(ucfirst($policy->status)); ?></span>
                                        </td>
                                        <td>

                                            <a href="<?php echo e(route('policies.edit', $policy->id)); ?>"
                                                class="btn btn-warning btn-sm"><i class="bi bi-pencil-fill"></i></a>
                                            <a href="<?php echo e(route('policies.details', $policy->id)); ?>"
                                                class="btn btn-primary btn-sm"><i class="bi bi-eye-fill"></i></a>
                                            <form action="<?php echo e(route('policies.destroy', $policy->id)); ?>" method="POST"
                                                style="display:inline-block;">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-danger btn-sm delete-btn"><i
                                                        class="bi bi-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/policies/index.blade.php ENDPATH**/ ?>