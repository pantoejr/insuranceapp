<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>