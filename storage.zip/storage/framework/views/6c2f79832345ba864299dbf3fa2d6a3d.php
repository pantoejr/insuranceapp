
<?php $__env->startSection('content'); ?>
    <div class="row p-3">
        <div class="col-md-12">
            <div class="row mb-3">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-6">
                            <p class="float-left">
                                <?php if($payment->status === 'approved'): ?>
                                    <span class="badge bg-success"><?php echo e(ucfirst($payment->status)); ?></span>
                                <?php elseif($payment->status === 'pending'): ?>
                                    <span class="badge bg-warning"><?php echo e(ucfirst($payment->status)); ?></span>
                                <?php else: ?>
                                    <span class="badge bg-primary p-2"><?php echo e(ucfirst($payment->status)); ?></span>
                                <?php endif; ?>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <div class="btn-group float-end" role="group">
                                <a href="<?php echo e(route('payments.downloadReceipt', ['id' => $payment->id])); ?>"
                                    class="btn btn-primary btn-sm"><i class="bi bi-file-pdf"></i> Download Receipt</a>
                                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                                    data-bs-target="#emailModal"><i class="bi bi-envelope-fill"></i> Email Receipt</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card shadow-sm border-0">
                <div class="card-body py-4 px-5">
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <img src="<?php echo e(asset('assets/images/VfPHgMS4ndKGxFSTrjGZDZqL5kpgXpnj2hTAZ8vn.png')); ?>"
                                alt="System Logo" width="200">
                        </div>
                        <div class="col-md-4"></div>
                        <div class="col-md-4">
                            <h4>PAYMENT RECEIPT</h4>
                            <p>
                                <b>Date:</b> <?php echo e(date('Y-m-d', strtotime($payment->payment_date))); ?><br>
                                <b>Status:</b> <?php echo e(ucfirst($payment->status)); ?>

                            </p>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <p>
                                <b><?php echo e(strtoupper($systemName)); ?></b><br>
                                <?php echo e($systemAddress); ?> <br>
                                <?php echo e($systemEmail); ?> <br>
                                <?php echo e($systemPhone); ?>

                            </p>
                        </div>
                        <div class="col-md-4"></div>
                        <div class="col-md-4">
                            <p>
                                <b><?php echo e($payment->invoice->client->full_name); ?></b><br>
                                <?php echo e($payment->invoice->client->address); ?><br>
                                <?php echo e($payment->invoice->client->phone); ?>

                            </p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered">
                                    <thead class="bg-light">
                                        <tr>
                                            <th>Invoice ID</th>
                                            <th>Amount Paid</th>
                                            <th>Payment Method</th>
                                            <th>Payment Reference</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><?php echo e($payment->invoice_id); ?></td>
                                            <td><?php echo e($payment->amount_paid); ?></td>
                                            <td><?php echo e(ucfirst($payment->payment_method)); ?></td>
                                            <td><?php echo e($payment->payment_reference); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-md-12">
                            <div class="form-group mb-3">
                                <label for="notes" class="form-label">Notes</label>
                                <input type="text" name="notes" id="notes" readonly class="form-control"
                                    value="<?php echo e($payment->notes); ?>" />
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group">
                            <?php $__currentLoopData = ['approved', 'rejected']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form action="<?php echo e(route('payments.updateStatus', $payment->id)); ?>" method="POST"
                                    style="display:inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="<?php echo e($status); ?>">
                                    <button type="submit"
                                        class="btn btn-<?php echo e($status == 'rejected' ? 'danger' : ($status == 'approved' ? 'success' : ($status == 'pending' ? 'warning' : 'secondary'))); ?>">
                                        <?php echo e(ucfirst($status)); ?>

                                    </button>
                                </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('payments.index')); ?>" class="btn btn-light">Back To List</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Email Modal -->
    <div class="modal fade" id="emailModal" tabindex="-1" aria-labelledby="emailModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form action="<?php echo e(route('payments.sendEmail', ['id' => $payment->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title" id="emailModalLabel">Send Receipt via Email</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="to_email" class="form-label">To</label>
                                    <input type="email" name="to_email" id="to_email" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="cc_email" class="form-label">CC</label>
                                    <input type="email" name="cc_email" id="cc_email" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="bcc_email" class="form-label">BCC</label>
                                    <input type="email" name="bcc_email" id="bcc_email" class="form-control">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group mb-3">
                                    <label for="subject" class="form-label">Subject</label>
                                    <input type="text" name="subject" id="subject" class="form-control" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group mb-3">
                            <label for="body" class="form-label">Body</label>
                            <textarea name="body" id="body" class="form-control" rows="4" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Send Email</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/payments/details.blade.php ENDPATH**/ ?>