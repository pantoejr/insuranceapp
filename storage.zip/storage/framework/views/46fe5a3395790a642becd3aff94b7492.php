
<?php $__env->startSection('content'); ?>
    <?php
        $sections = [
            [
                'id' => 'section1',
                'title' => 'Details',
                'view' => 'insurers.partials.insurer_details',
                'icons' => 'bi bi-person',
            ],
            [
                'id' => 'section2',
                'title' => 'Users',
                'view' => 'insurers.partials.user_list',
                'icons' => 'bi bi-people',
            ],
            [
                'id' => 'section3',
                'title' => 'Policies',
                'view' => 'insurers.partials.policies_list',
                'icons' => 'bi bi-paperclip',
            ],
        ];
    ?>

    <?php if (isset($component)) { $__componentOriginalbd0859f50456e91054bbf3843cf921d7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbd0859f50456e91054bbf3843cf921d7 = $attributes; } ?>
<?php $component = App\View\Components\SectionNavigation::resolve(['sections' => $sections,'model' => $insurer,'users' => $users,'policies' => $policies] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section-navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SectionNavigation::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbd0859f50456e91054bbf3843cf921d7)): ?>
<?php $attributes = $__attributesOriginalbd0859f50456e91054bbf3843cf921d7; ?>
<?php unset($__attributesOriginalbd0859f50456e91054bbf3843cf921d7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbd0859f50456e91054bbf3843cf921d7)): ?>
<?php $component = $__componentOriginalbd0859f50456e91054bbf3843cf921d7; ?>
<?php unset($__componentOriginalbd0859f50456e91054bbf3843cf921d7); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/insurers/details.blade.php ENDPATH**/ ?>