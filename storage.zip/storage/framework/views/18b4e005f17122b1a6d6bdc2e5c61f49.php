<li class="nav-item dropdown">
    <a class="nav-link" data-bs-toggle="dropdown" href="#">
        <i class="bi bi-bell-fill"></i>
        <?php if(auth()->user()->unreadNotifications->count() > 0): ?>
            <span class="navbar-badge badge text-bg-warning">
                <?php echo e(auth()->user()->unreadNotifications->count()); ?>

            </span>
        <?php endif; ?>
    </a>
    <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end">
        <span class="dropdown-item dropdown-header">
            <?php echo e(auth()->user()->unreadNotifications->count()); ?> Notifications
        </span>
        <div class="dropdown-divider"></div>

        <?php $__empty_1 = true; $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <button class="dropdown-item mark-as-read text-wrap" style="font-size: 13px;"
                data-notification-id="<?php echo e($notification->id); ?>"
                data-redirect-url="<?php echo e(route('notifications.markAsRead')); ?>">
                <?php if($notification->type === 'App\Notifications\PolicyAssignmentSubmittedNotification'): ?>
                    <i class="bi bi-envelope me-2"></i>
                    <?php echo e($notification->data['message']); ?>

                <?php else: ?>
                    <i class="bi bi-envelope me-2"></i>
                    <?php echo e($notification->data['message'] ?? 'New notification'); ?>

                <?php endif; ?>
                <span class="float-end text-secondary fs-7" style="font-size: 13px;">
                    <?php echo e($notification->created_at->diffForHumans()); ?>

                </span>
            </button>
            <div class="dropdown-divider"></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <a href="#" class="dropdown-item">
                <i class="bi bi-info-circle me-2"></i>
                No new notifications
            </a>
        <?php endif; ?>
    </div>
</li>
<?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/partials/notification.blade.php ENDPATH**/ ?>