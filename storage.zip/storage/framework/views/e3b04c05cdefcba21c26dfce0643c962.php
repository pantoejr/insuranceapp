<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice <?php echo e($invoice->invoice_id); ?></title>
</head>

<body>
    <p>Dear <?php echo e($invoice->client->full_name); ?>,</p>
    <p>Please find attached the invoice <?php echo e($invoice->invoice_id); ?>.</p>
    <p>Thank you for your business.</p>
    <p>Best regards,<br><?php echo e(strtoupper(env('APP_NAME'))); ?></p>
</body>

</html>
<?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/emails/invoice.blade.php ENDPATH**/ ?>