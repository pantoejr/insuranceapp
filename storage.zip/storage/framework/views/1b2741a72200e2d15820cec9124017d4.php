<form wire:submit.prevent="submit">
    <?php echo csrf_field(); ?>
    <!--[if BLOCK]><![endif]--><?php if(empty($availablePermissions)): ?>
        <p>No permissions available to assign. This role may already have all permissions.</p>
    <?php else: ?>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $availablePermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissionId => $permissionName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group">
                <input wire:model="selectedPermissions" type="checkbox" value="<?php echo e($permissionName); ?>"
                    id="<?php echo e($permissionName); ?>" />
                <label for="<?php echo e($permissionName); ?>"><?php echo e($permissionName); ?></label>
            </div>
            <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        <button type="submit" class="btn btn-success w-100">Assign Permissions</button>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</form>
<?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/livewire/role/add-permission.blade.php ENDPATH**/ ?>