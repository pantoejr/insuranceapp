<div class="row">
    <div class="col-md-12">
        <div class="card shadow-sm mb-4 border-0" style="min-height: 450px;">
            <div class="card-header">
                <?php echo $__env->make('insurers.partials.add_or_edit_user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div class="card-title" id="user-header" style="cursor: pointer;">Insurer User</div>
                <div class="card-tools">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addInsurerUserModal"><i
                            class="bi bi-plus-circle"></i></button>
                </div>
            </div>
            <div class="card-body" id="user-body">
                <div class="table-responsive">
                    <table class="table dataTable">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Insurer</th>
                                <th>User</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $model->assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($assignment->insurer->company_name); ?></td>
                                    <td><?php echo e($assignment->user->name); ?></td>
                                    <td><?php echo e(ucfirst($assignment->role)); ?></td>
                                    <td><?php echo e(ucfirst($assignment->status)); ?></td>
                                    <td>
                                        <button class="btn btn-warning  btn-sm edit-btn" data-bs-toggle="modal"
                                            data-bs-target="#editInsurerUserModal"
                                            data-insurerAssignment-id=<?php echo e($assignment->id); ?>><i
                                                class="bi bi-pencil-fill"></i></button>
                                        <form
                                            action="<?php echo e(route('insurer-assignments.destroy', ['insurer' => $model, 'insurerAssignment' => $assignment])); ?>"
                                            method="POST" style="display:inline-block;">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger btn-sm delete-btn">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/insurers/partials/user_list.blade.php ENDPATH**/ ?>