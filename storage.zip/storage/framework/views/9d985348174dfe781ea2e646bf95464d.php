
<?php $__env->startSection('content'); ?>
    <div class="row">

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/assign_policy/edit.blade.php ENDPATH**/ ?>