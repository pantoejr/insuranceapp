<div class="row">
    <div class="col-md-12">
        <div class="card shadow-sm mb-4" style="border:none;">
            <div class="card-header" style="border:none;">
                <div class="card-title" id="policy-header" style="cursor: pointer;">Insurer Policies</div>
                <div class="card-tools">
                    <a href="#" class="btn btn-primary" data-bs-toggle="modal"
                        data-bs-target="#assignPoliciesModal">
                        <i class="bi bi-plus-circle"></i>
                    </a>
                </div>
                <?php echo $__env->make('insurers.partials.edit_policy', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
            <div class="card-body" id="policy-body" style="min-height: 400px;">
                <div class="table-responsive">
                    <table class="table dataTable nowrap">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Insurer</th>
                                <th>Policy</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $model->insurerPolicies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurerPolicy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($insurerPolicy->insurer->company_name); ?></td>
                                    <td><?php echo e($insurerPolicy->policy->name); ?></td>
                                    <td><?php echo e(ucfirst($insurerPolicy->status)); ?></td>
                                    <td>
                                        <button class="btn btn-warning btn-sm edit-policy-btn" data-bs-toggle="modal"
                                            data-bs-target="#editModal" data-insurer-id="<?php echo e($model->id); ?>"
                                            data-insurerPolicy-id="<?php echo e($insurerPolicy->id); ?>">
                                            <i class="bi bi-pencil-fill"></i>
                                        </button>
                                        <form
                                            action="<?php echo e(route('insurers.removeInsurerPolicy', ['id' => $insurerPolicy->id, 'insurerId' => $model->id])); ?>"
                                            method="POST" style="display:inline-block;">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger btn-sm delete-btn">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Assign Policies Modal -->
<div class="modal fade" id="assignPoliciesModal" tabindex="-1" aria-labelledby="assignPoliciesModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="assignPoliciesModalLabel">Assign Policies to Insurer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="assignPoliciesForm" action="<?php echo e(route('insurers.storeMultiplePolicies')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-3">
                        <label for="insurer_id" class="form-label">Insurer</label>
                        <select class="form-control <?php $__errorArgs = ['insurer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="insurer_id"
                            name="insurer_id" required>
                            <option value="<?php echo e($model->id); ?>"><?php echo e($model->company_name); ?></option>
                        </select>
                        <?php $__errorArgs = ['insurer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group mb-3">
                        <label for="policy_ids" class="form-label">Policies</label>
                        <select class="form-control <?php $__errorArgs = ['policy_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="policy_ids"
                            name="policy_ids[]" multiple required>
                            <?php $__currentLoopData = $policies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $policy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($policy->id); ?>"><?php echo e($policy->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['policy_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status" name="status"
                            required>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-success">Save</button>
                        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
        $('#assignPoliciesForm').on('submit', function(event) {
            event.preventDefault();
            $.ajax({
                url: $(this).attr('action'),
                method: $(this).attr('method'),
                data: $(this).serialize(),
                success: function(response) {
                    if (response.flag === 'success') {
                        $('#assignPoliciesModal').modal('hide');
                        Swal.fire({
                            title: "Success",
                            text: "Policy assigned successfully",
                            icon: "success",
                            draggable: true,
                        });
                        location.reload();
                    } else {
                        Swal.fire({
                            title: "Error",
                            text: "An error occured while assigning the policies",
                            icon: "error",
                            draggable: true,
                        });
                    }
                },
                error: function(xhr) {
                    Swal.fire({
                        title: "Error",
                        text: "An error occured while assigning the policies",
                        icon: "error",
                        draggable: true,
                    });
                }
            });
        });
    });
</script>
<?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/insurers/partials/policies_list.blade.php ENDPATH**/ ?>