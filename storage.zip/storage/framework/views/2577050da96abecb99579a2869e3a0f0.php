

<?php $__env->startSection('content'); ?>
    <div class="row mb-3">
        <div class="col-md-12">
            <div class="card shadow-sm mb-4" style="border:none;">
                <div class="card-header">
                    <div class="card-title">
                        <?php echo e($employee->client->full_name); ?> Employee Details
                    </div>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-4 p-3 text-center">
                            <?php if($employee->profile_picture): ?>
                                <img src="<?php echo e(asset('storage/' . $employee->profile_picture)); ?>" alt="Employee Photo"
                                    style="max-width: 70%;" class="card-img">
                            <?php else: ?>
                                <img src="#" alt="No Photo" style="max-width: 100%; display: none;">
                            <?php endif; ?>
                        </div>
                        <div class="col-md-8">
                            <div class="row p-3">
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="employee_name" class="form-label">Employee Name</label>
                                        <input type="text" class="form-control" id="employee_name"
                                            value="<?php echo e($employee->employee_name); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="email" class="form-label">Email</label>
                                        <input type="email" class="form-control" id="email"
                                            value="<?php echo e($employee->email); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="phone" class="form-label">Phone</label>
                                        <input type="text" class="form-control" id="phone"
                                            value="<?php echo e($employee->phone); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="position" class="form-label">Position</label>
                                        <input type="text" class="form-control" id="position"
                                            value="<?php echo e($employee->position); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="gender" class="form-label">Gender</label>
                                        <input type="text" class="form-control" id="gender"
                                            value="<?php echo e(ucfirst($employee->gender)); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="status" class="form-label">Status</label>
                                        <input type="text" class="form-control" id="status"
                                            value="<?php echo e(ucfirst($employee->status)); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="address" class="form-label">Address</label>
                                        <input type="text" class="form-control" id="address"
                                            value="<?php echo e($employee->address); ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="date_of_birth" class="form-label">Date of Birth</label>
                                        <input type="date" class="form-control" id="date_of_birth"
                                            value="<?php echo e($employee->date_of_birth); ?>" readonly>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <a href="<?php echo e(route('clients.details', ['id' => $client->id])); ?>"
                                        class="btn btn-light">Back
                                        to
                                        List</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('employees.partials.employee_dependents', ['employee' => $employee], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('employees.partials.employee_attachment', ['employee' => $employee], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/employees/details.blade.php ENDPATH**/ ?>