<?php $__env->startSection('content'); ?>
    <h4 class="mb-3">Dashboard</h4>
    <div class="row mb-2">
        <div class="col-md-4">
            <div class="info-box">
                <span class="info-box-icon border-0 text-bg-primary shadow-sm">
                    <i class="bi bi-people-fill"></i>
                </span>
                <div class="info-box-content">
                    <span class="info-box-text">No. of Clients</span>
                    <span class="info-box-number">
                        <?php echo e($clientCount = \App\Models\Client::count()); ?>

                    </span>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="info-box">
                <span class="info-box-icon border-0 text-bg-danger shadow-sm">
                    <i class="bi bi-people-fill"></i>
                </span>
                <div class="info-box-content">
                    <span class="info-box-text">No. of Insurers</span>
                    <span class="info-box-number">
                        <?php echo e($insurersCount = \App\Models\Insurer::count()); ?>

                    </span>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="info-box">
                <span class="info-box-icon border-0 text-bg-success shadow-sm">
                    <i class="bi bi-journal-text"></i>
                </span>
                <div class="info-box-content">
                    <span class="info-box-text">No. of Policies</span>
                    <span class="info-box-number">
                        <?php echo e($policyCount = \App\Models\Policy::count()); ?>

                    </span>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-header">
                    <div class="card-title">Policy Assigned / Clients</div>
                </div>
                <div class="card-body">

                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-header">
                    <div class="card-title">Claims / Clients</div>
                </div>
                <div class="card-body">

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\HP User\Desktop\Laravel Projects\insuranceapp\resources\views/home/index.blade.php ENDPATH**/ ?>